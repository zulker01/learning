package com.example.sql_server_crud.sql_server_crud;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SqlServerCrudApplicationTests {

	@Test
	void contextLoads() {
	}

}
